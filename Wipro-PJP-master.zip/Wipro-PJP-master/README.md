# Wipro-PJP
Wipro Pre Joining Program (Java J2EE) : Hands-On Assignments and Mini-Projects Solutions
